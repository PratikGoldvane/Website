export function Label({ children }) {
  return <label className="block mb-1 font-medium">{children}</label>;
}